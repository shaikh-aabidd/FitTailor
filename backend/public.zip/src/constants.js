

export const DB_NAME = process.env.NODE_ENV==="development"? "fitTailor" : "fitTailor-test"