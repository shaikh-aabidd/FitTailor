import { asyncHandler } from "../utils/asyncHandler.js";
import { ApiError } from "../utils/ApiError.js";
import { ApiResponse } from "../utils/ApiResponse.js";
import { Product } from "../models/product.model.js";
import {
  deleteFromCloudinary,
  uploadOnCloudinary,
} from "../utils/cloudinary.js";
import mongoose from "mongoose";
// Create New Product (Admin Only)
const createProduct = asyncHandler(async (req, res) => {
  const {
    name,
    description,
    price,
    fabricType,
    category,
    stock,
    designOptions,
  } = req.body;

  // Validate required fields
  if (
    !name ||
    (typeof name === "string" && name.trim() === "") ||
    price == null || // check for undefined or null
    !fabricType ||
    (typeof fabricType === "string" && fabricType.trim() === "") ||
    !category ||
    (typeof category === "string" && category.trim() === "")
  ) {
    throw new ApiError(
      400,
      "Name, Price, Fabric Type and Category are required"
    );
  }

  // Check product already exist
  const productExist = await Product.exists({ name });
  if (productExist)
    throw new ApiError(400, "Product with the same name already exist");

  // Handle image upload
  const images = [];
  if (
    req.files &&
    Array.isArray(req.files.images) &&
    req.files.images.length > 0
  ) {
    for (const file of req.files.images) {
      const result = await uploadOnCloudinary(file.path);
      images.push(result.url);
    }
  }

  // Create product
  const product = await Product.create({
    name,
    description: description || "",
    price,
    fabricType,
    images,
    stock: stock || 0,
    category,
    designOptions: designOptions || {
      collarStyles: [],
      sleeveTypes: [],
    },
  });

  return res
    .status(201)
    .json(new ApiResponse(201, product, "Product created successfully"));
});

// Get All Products
const getAllProducts = asyncHandler(async (req, res) => {
  const { page = 1, limit = 10, category, fabricType } = req.query;

  const filter = {};

  if (category) filter.category = category;

  // If multiple fabricTypes are provided, filter using $in
  if (fabricType) {
    if (Array.isArray(fabricType)) {
      filter.fabricType = { $in: fabricType };
    } else if (typeof fabricType === 'string') {
      // Support comma-separated string like "cotton,silk"
      const fabricList = fabricType.split(',').map(item => item.trim());
      filter.fabricType = fabricList.length > 1 ? { $in: fabricList } : fabricList[0];
    }
  }

  const options = {
    page: parseInt(page),
    limit: parseInt(limit),
    sort: { createdAt: -1 },
  };

  const products = await Product.aggregatePaginate(
    Product.aggregate([
      { $match: filter },
      { $project: { __v: 0 } }
    ]),
    options
  );

  return res
    .status(200)
    .json(new ApiResponse(200, products, "Products fetched successfully"));
});

// Get Single Product by ID
const getProductById = asyncHandler(async (req, res) => {
  const { productId } = req.params;

  if (!productId) {
    throw new ApiError(400, "Product ID is required");
  }

  const product = await Product.findById(productId).select("-__v");

  if (!product) {
    throw new ApiError(404, "Product not found");
  }

  return res
    .status(200)
    .json(new ApiResponse(200, product, "Product fetched successfully"));
});

// Update Product (Admin Only)
const updateProduct = asyncHandler(async (req, res) => {
  const { productId } = req.params;
  const updateData = req.body;

  if (!productId) {
    throw new ApiError(400, "Product ID is required");
  }

  // Handle image updates
  if (req.files && req.files.images) {
    const images = [];
    for (const file of req.files.images) {
      const result = await uploadOnCloudinary(file.path);
      images.push(result.url);
    }
    updateData.images = images;
  }

  const updatedProduct = await Product.findByIdAndUpdate(
    productId,
    { $set: updateData },
    { new: true, runValidators: true }
  ).select("-__v");

  if (!updatedProduct) {
    throw new ApiError(404, "Product not found");
  }

  return res
    .status(200)
    .json(new ApiResponse(200, updatedProduct, "Product updated successfully"));
});

// Delete Product (Admin Only)
const deleteProduct = asyncHandler(async (req, res) => {
  const { productId } = req.params;

  // 1) Validate ID
  if (!mongoose.Types.ObjectId.isValid(productId)) {
    throw new ApiError(400, "Invalid Product ID");
  }

  // 2) Find the product
  const product = await Product.findById(productId);
  if (!product) {
    throw new ApiError(404, "Product not found");
  }

  // 3) Remove it from the database
  await Product.findByIdAndDelete(productId);

  // 4) Delete each image from Cloudinary in parallel
  if (product.images && product.images.length > 0) {
    await Promise.all(
      product.images.map((imgUrl) => deleteFromCloudinary(imgUrl))
    );
  }

  // 5) Respond
  return res
    .status(200)
    .json(new ApiResponse(200, {}, "Product deleted successfully"));
});

export {
  createProduct,
  getAllProducts,
  getProductById,
  updateProduct,
  deleteProduct,
};
