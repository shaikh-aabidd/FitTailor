import React from 'react';

const InfoSection = () => (
  <section className="py-12">
    <div className="container mx-auto px-4 flex flex-col md:flex-row items-center gap-8">
      {/* YouTube Video Embed */}
      <div className="w-full md:w-1/2 aspect-video">
      <iframe width="560" height="315" src="https://www.youtube.com/embed/ECnC3Meyff4?si=s1PncG2mNQlmn06b" title="YouTube video player" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerPolicy="strict-origin-when-cross-origin" allowFullScreen></iframe>
      </div>

      <div className="md:w-1/2">
        <h2 className="text-3xl font-display text-primary mb-4">Why Go Bespoke?</h2>
        <ul className="list-disc list-inside text-gray-700 space-y-2">
          <li>Perfect fit</li>
          <li>Premium fabrics</li>
          <li>Handcrafted details</li>
        </ul>
        <button className="mt-6 px-6 py-3 bg-primary text-white rounded-xl font-semibold hover:bg-primary-light transition">
          Get Started
        </button>
      </div>
    </div>
  </section>
);

export default InfoSection;
