import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useForm } from "react-hook-form";
import Loader from "../components/Loader";
import Button from "../components/Button";
import { useGetCurrentUserQuery } from "../features/api/user.api";
import { setCredentials } from "../features/auth/authSlice";
import { useCreateOrderMutation } from "../features/api/order.api";
import { useGetAllMeasurementsQuery, useGetMeasurementByIdQuery } from "../features/api/measurement.api";
import { toast } from "react-toastify";
import { useClearCartMutation } from "../features/api/cart.api";
import { useNavigate } from "react-router-dom";

export default function Checkout() {
  const customization = useSelector((state) => state.customization);

  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { data, isLoading } = useGetCurrentUserQuery();

  const user = useSelector(state=>state.auth.user) || {};
  const [createOrder, {isLoading: creating }] = useCreateOrderMutation();

  const { data:Measurements, isLoading: isFetching } = useGetAllMeasurementsQuery();
  const [clearCart,{isLoading:cartLoading}] = useClearCartMutation();
// console.log(Measurements.data[0]?._id)
  useEffect(() => {
    if (data?.data) {
      dispatch(setCredentials(data.data));
    }
  }, [data, dispatch]);

  const cartItems = useSelector((s) => s.auth.user?.cart) || [];
  console.log("cartItem",cartItems)
  // Determine default address
  const defaultAddress =
    user.addresses?.find((a) => a.isDefault) || user.addresses?.[0] || {};
  const [selectedAddressId, setSelectedAddressId] = useState(
    defaultAddress._id || ""
  );

  // Form setup
  const { register, handleSubmit, reset } = useForm({
    defaultValues: {
      street: defaultAddress.street || "",
      city: defaultAddress.city || "",
      state: defaultAddress.state || "",
      zipCode: defaultAddress.zipCode || "",
      comment: "",
    },
  });

  // When selectedAddressId changes, update form values
  useEffect(() => {
    const addr = user.addresses?.find((a) => a._id === selectedAddressId) || {};
    reset({
      street: addr.street || "",
      city: addr.city || "",
      state: addr.state || "",
      zipCode: addr.zipCode || "",
      comment: "",
    });
  }, [selectedAddressId, user.addresses, reset]);

  const [paymentMethod, setPaymentMethod] = useState("cod");

  const onSubmit = (data) => {
    const orderPayload = {
      address: { ...data },
      paymentMethod,

      customProduct: customization?.garment
    ? {
        garment: customization.garment,
        fabric: customization.fabric,
        designChoices: customization.designChoices,
        measurementData: customization.measurementData,
        tailor: customization.tailorInfo,
        addOns: customization.addOns,
        price: getCustomizationPrice(),
      }
    : null,

      items: cartItems.map((i) => ({
        productId: i.product._id,
        quantity: i.quantity,
      })),
      total: cartItems.reduce((sum, i) => sum + i.product.price * i.quantity, 0),
      comment: data.comment,
    };
    console.log("Submitting order:", orderPayload);
    createOrderFunction(orderPayload);

    // TODO: call your checkout API mutation here
  };

  const createOrderFunction = async (orderPayload) => {
    const { address, items, customProduct, paymentMethod, comment } = orderPayload;
    try {
      // Custom garment order
      if (customProduct) {
        await createOrder({
          productId: customProduct.productId,
          measurementId: customization.measurementProfileId
            || customProduct.measurementData._id,
          designChoices: customProduct.designChoices,
          deliveryAddress: address,
          tailorNotes: comment,
          quantity: 1,
          paymentMethod,
          totalAmount: customProduct.price,
        }).unwrap();
      }
  
      // Readymade items
      for (const { productId, quantity } of items) {
        await createOrder({
          productId,
          measurementId: null,
          designChoices: {},
          deliveryAddress: address,
          tailorNotes: comment,
          quantity,
          paymentMethod,
        }).unwrap();
      }

      const res = await clearCart();
      console.log("clearCart ",res)
      navigate("/orders/track")
      toast.success('All items ordered successfully!');
    } catch (err) {
      console.error('Order creation failed', err);
      toast.error(err.data?.message || 'Failed to create order');
    }
  };
  
  

  const getCustomizationPrice = () => {
    let basePrice = 100; // base price for custom garment
    let addOnPrice = 0;
  
    if (customization.addOns?.monogramming) addOnPrice += 10;
    if (customization.addOns?.giftWrapping) addOnPrice += 5;
    if (customization.addOns?.expressDelivery) addOnPrice += 20;
    if (customization.addOns?.careKit) addOnPrice += 15;
  
    return basePrice + addOnPrice;
  };

  // Total calculation
  const totalAmount = cartItems.reduce(
    (sum, i) => sum + i.product.price * i.quantity,
    0 + (customization?.garment ? getCustomizationPrice() : 0)
  );

  if (isLoading || !user || !user.addresses || creating || isFetching || cartLoading) {
    return <div>Loading...</div>;
  }

  if (!user || (!user.addresses && user.addresses.length === 0)) {
    return <Loader fullScreen />;
  }

  return (
    <div className="container mx-auto p-6 grid grid-cols-1 lg:grid-cols-4 gap-6">
      {/* Left: Address form (3 cols) */}
      <div className="lg:col-span-3 bg-white p-6 rounded-lg shadow">
        <h2 className="text-2xl font-semibold mb-4">Delivery Address</h2>
        {/* Address selection */}
        <div className="space-y-2 mb-6">
          {user.addresses.map((addr) => (
            <label key={addr._id} className="flex items-start space-x-3">
              <input
                type="radio"
                name="selectedAddress"
                value={addr._id}
                checked={selectedAddressId === addr._id}
                onChange={() => setSelectedAddressId(addr._id)}
                className="mt-1"
              />
              <div>
                <p className="font-medium">
                  {addr.street}, {addr.city}
                </p>
                <p className="text-sm text-gray-600">
                  {addr.state}, {addr.zipCode} ({addr.type})
                </p>
              </div>
            </label>
          ))}
        </div>

        {/* Editable address form */}
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Street</label>
              <input
                {...register("street")}
                className="w-full p-2 border rounded-lg"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">City</label>
              <input
                {...register("city")}
                className="w-full p-2 border rounded-lg"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">State</label>
              <input
                {...register("state")}
                className="w-full p-2 border rounded-lg"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Zip Code</label>
              <input
                {...register("zipCode")}
                className="w-full p-2 border rounded-lg"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">
              Additional Comments
            </label>
            <textarea
              {...register("comment")}
              rows={3}
              className="w-full p-2 border rounded-lg"
            />
          </div>
          {/* Submit hidden here, real submit via right panel */}
        </form>
      </div>

      {/* Right: Order summary & payment (1 col) */}
      <div className="bg-white p-6 rounded-lg shadow space-y-6">
        <h2 className="text-2xl font-semibold">Order Summary</h2>
        <div className="space-y-4">
          {cartItems.map((item) => (
            <div key={item.product.productId} className="flex justify-between">
              <span>
                {item.product.name} x {item.quantity}
              </span>
              <span>${(item.product.price * item.quantity).toFixed(2)}</span>
            </div>
          ))}

          {customization?.garment && (
            <div className="border-t pt-4 space-y-2">
              <h3 className="text-lg font-semibold">Customized Garment</h3>
              <p>
                <strong>Type:</strong> {customization.garment}
              </p>
              <p>
                <strong>Fabric:</strong> {customization.fabric}
              </p>
              <p>
                <strong>Collar:</strong> {customization.designChoices?.collar}
              </p>
              <p>
                <strong>Sleeves:</strong> {customization.designChoices?.sleeves}
              </p>
              <p>
                <strong>Tailor:</strong> {customization.tailorInfo?.name}
              </p>
              <p>
                <strong>Add‑Ons:</strong>{" "}
                {Object.keys(customization.addOns || {})
                  .filter((key) => customization.addOns[key])
                  .map((key) => key.replace(/([A-Z])/g, " $1"))
                  .join(", ") || "None"}
              </p>
            </div>
          )}
        </div>
        <div className="border-t pt-4 flex justify-between font-medium">
          <span>Total</span>
          <span>${totalAmount.toFixed(2)}</span>
        </div>

        {/* Payment options */}
        <div className="mt-4">
          <h3 className="font-medium mb-2">Payment Method</h3>
          <label className="flex items-center space-x-2">
            <input
              type="radio"
              value="cod"
              checked={paymentMethod === "cod"}
              onChange={() => setPaymentMethod("cod")}
              className="mt-1"
            />
            <span>Cash on Delivery</span>
          </label>
          <label className="flex items-center space-x-2 mt-2">
            <input
              type="radio"
              value="online"
              checked={paymentMethod === "online"}
              onChange={() => setPaymentMethod("online")}
              className="mt-1"
            />
            <span>Online Payment</span>
          </label>
        </div>

        <Button
          onClick={handleSubmit(onSubmit)}
          className="w-full py-2 bg-blue-600 text-white rounded-lg"
        >
          Pay Now
        </Button>
      </div>
    </div>
  );
}
