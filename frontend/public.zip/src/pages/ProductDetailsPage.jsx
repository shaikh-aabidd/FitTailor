import React from 'react';
import { ProductDetails } from '../components';

const ProductDetailsPage = () => {
    return (
        <div>
            <ProductDetails />
        </div>
    );
};

export default ProductDetailsPage;