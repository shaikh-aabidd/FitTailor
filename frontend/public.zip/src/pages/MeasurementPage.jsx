import React from 'react';
import { Measurement } from '../components';

const MeasurementPage = () => {
    return (
        <div>
            <Measurement />
        </div>
    );
};

export default MeasurementPage;