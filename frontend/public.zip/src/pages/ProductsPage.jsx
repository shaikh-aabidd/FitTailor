import React from 'react';
import { ProductListing } from '../components';

const ProductsPage = () => {
    return (
        <div>
            <ProductListing />
        </div>
    );
};

export default ProductsPage;