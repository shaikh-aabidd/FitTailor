import React from 'react';
import { Checkout } from '../components';

const CheckoutPage = () => {
    return (
        <div>
           <Checkout/>
        </div>
    );
};

export default CheckoutPage;