// src/components/Profile.jsx
import React from 'react';
import { Profile } from '../components';

const ProfilePage = () => {
    return(
        <>
            <Profile />
        </>
    )
  
};

export default ProfilePage;
