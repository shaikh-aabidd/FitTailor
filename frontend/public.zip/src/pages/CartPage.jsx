import React from 'react';
import { CartList } from '../components';

const CartPage = () => {
    return (
        <div>
            <CartList />
        </div>
    );
};

export default CartPage;