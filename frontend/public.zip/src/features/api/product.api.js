import { apiSlice } from "./apiSlice";

export const productApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    getAllProducts: builder.query({
      query: ({ page = 1, limit = 12, category, fabricType }) => ({
        url: '/products',
        params: {
          page,
          limit,
          category,
          fabricType: Array.isArray(fabricType) ? fabricType : [fabricType]
        }
      }),
      transformResponse: (response) => {
        if (response?.success) {
          return response.data;
        }
        return [];
      }
    }),
    getProductById: builder.query({
      query: (id) => `/products/${id}`,
      providesTags: (result, error, { id }) => [{ type: "Product", id }],
    }),

    createProduct: builder.mutation({
      query: (productData) => {
        const formData = new FormData();
        Object.entries(productData).forEach(([key, value]) => {
          if (key === "images") {
            value.forEach((file) => formData.append("images", file));
          } else {
            formData.append(key, value);
          }
        });

        return {
          url: "/products",
          method: "POST",
          body: formData,
        };
      },
    }),

    updateProduct: builder.mutation({
      query: ({ productId, updatedData }) => {
        const formData = new FormData();

        // Append images if present (only if user uploaded new ones)
        if (updatedData.images && Array.isArray(updatedData.images)) {
          updatedData.images.forEach((file) => {
            formData.append("images", file);
          });
        }

        // Append other fields
        Object.entries(updatedData).forEach(([key, value]) => {
          if (key !== "images") {
            formData.append(key, value);
          }
        });

        return {
          url: `/products/${productId}`,
          method: "PATCH",
          body: formData,
        };
      },

      invalidatesTags: (result, error, { productId }) => [
        { type: "Product", id: productId },
        { type: "Product", id: "LIST" },
      ],
    }),

    deleteProduct: builder.mutation({
      query: (id) => ({
        url: `/products/${id}`,
        method: "DELETE",
      }),
      invalidatesTags: ["Product"],
    }),
  }),
});

export const {
  useGetAllProductsQuery,
  useGetProductByIdQuery,
  useCreateProductMutation,
  useUpdateProductMutation,
  useDeleteProductMutation,
} = productApi;
